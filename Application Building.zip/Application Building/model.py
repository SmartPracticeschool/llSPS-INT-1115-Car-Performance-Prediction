# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle

dataset = pd.read_csv('auto-mpg.csv')

dataset['weight'].fillna(dataset['weight'].mean(), inplace=True)

dataset['horsepower']=dataset['horsepower'].replace('?',np.nan)

dataset['horsepower']=dataset['horsepower'].astype('float64')

dataset['horsepower'].fillna(dataset['horsepower'].mean(),inplace=True)

dataset=dataset.drop('car name',axis=1)

from sklearn.preprocessing import LabelEncoder
labelencoder_y=LabelEncoder()
dataset['Engine Fuel Type']=labelencoder_y.fit_transform(dataset['Engine Fuel Type'])

X = dataset.iloc[:, 1:9]

#Converting words to integer values

y = dataset.iloc[:, 0]

#Splitting Training and Test Set
#Since we have a very small dataset, we will train our model with all availabe data.

from sklearn.tree import DecisionTreeRegressor
regressor = DecisionTreeRegressor(random_state=0)

#Fitting model with trainig data
regressor.fit(X, y)

# Saving model to disk
pickle.dump(regressor, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
print(model.predict([[8,310,200,4120,12.5,80,3,4]]))