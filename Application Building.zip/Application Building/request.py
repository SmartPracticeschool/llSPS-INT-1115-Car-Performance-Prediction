import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'cylinders':8, 'displacement':310, 'horsepower':200,'weight':4120,'acceleration':12.5,'model year':80 ,'origin':3,'Engine Fuel Type':4})

print(r.json())
